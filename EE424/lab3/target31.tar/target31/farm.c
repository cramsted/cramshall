/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_412()
{
    return 2417496824U;
}

unsigned addval_453(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_440(unsigned x)
{
    return x + 2425444499U;
}

unsigned getval_298()
{
    return 3251079496U;
}

void setval_365(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_254()
{
    return 3347662885U;
}

unsigned getval_344()
{
    return 2462550344U;
}

unsigned addval_346(unsigned x)
{
    return x + 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_135(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_321()
{
    return 3281046153U;
}

unsigned getval_250()
{
    return 3687110281U;
}

void setval_102(unsigned *p)
{
    *p = 3373842825U;
}

void setval_122(unsigned *p)
{
    *p = 3378563721U;
}

void setval_230(unsigned *p)
{
    *p = 3676357000U;
}

unsigned getval_415()
{
    return 3247115498U;
}

unsigned addval_189(unsigned x)
{
    return x + 2428600782U;
}

unsigned addval_474(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_269(unsigned x)
{
    return x + 3676362377U;
}

void setval_209(unsigned *p)
{
    *p = 3378566793U;
}

unsigned addval_482(unsigned x)
{
    return x + 2428602818U;
}

unsigned addval_377(unsigned x)
{
    return x + 3281043849U;
}

void setval_191(unsigned *p)
{
    *p = 3599363810U;
}

void setval_277(unsigned *p)
{
    *p = 3380920712U;
}

void setval_317(unsigned *p)
{
    *p = 3399041226U;
}

unsigned addval_112(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_134(unsigned x)
{
    return x + 3767091408U;
}

void setval_106(unsigned *p)
{
    *p = 3252062615U;
}

unsigned addval_145(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_150(unsigned x)
{
    return x + 3676356873U;
}

unsigned getval_220()
{
    return 2425670281U;
}

unsigned addval_246(unsigned x)
{
    return x + 3381971593U;
}

unsigned addval_110(unsigned x)
{
    return x + 3536112265U;
}

void setval_445(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_480(unsigned x)
{
    return x + 3682915981U;
}

unsigned addval_337(unsigned x)
{
    return x + 3281180297U;
}

unsigned addval_170(unsigned x)
{
    return x + 3372275337U;
}

unsigned getval_192()
{
    return 3676359305U;
}

unsigned getval_195()
{
    return 3766569063U;
}

unsigned addval_447(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_487()
{
    return 3682912921U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
